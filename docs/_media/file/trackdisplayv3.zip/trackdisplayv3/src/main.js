import { createApp } from "vue";
import App from "./App.vue";
import '@vuemap/vue-amap/dist/style.css'
import 'view-ui-plus/dist/styles/viewuiplus.css'
import ViewUIPlus from 'view-ui-plus'

import VueAMap, { initAMapApiLoader } from '@vuemap/vue-amap';

initAMapApiLoader({
  // 高德的key
  key: '7333fda4f079977bb5596730631c7075',
  // 插件集合
  plugin: [
    'AMapManager',
    'AMap.Autocomplete',
    'AMap.PlaceSearch',
    'AMap.Scale',
    'AMap.OverView',
    'AMap.ToolBar',
    'AMap.MapType',
    'AMap.PolyEditor',
    'AMap.CircleEditor',
    'Geocoder',
    'Geolocation',
    'AMap.MarkerClusterer',
    'AMap.PolyEditor',
    'AMap.CircleEditor',
    'AMap.MouseTool',
    'AMap.Driving',
    'AMap.CitySearch',
    'AMap.InfoWindow',
    'AMap.LngLat',
    'AMap.DistrictSearch',
    'AMap.TileLayer.Traffic',
    'AMap.Heatmap',
    'AMap.Autocomplete',
    'AMap.PlaceSearch'
  ],
  AMapUI: {},
  // 高德 sdk 版本，默认为 1.4.4
  v: '1.4.4'
})

const app = createApp(App);
app.use(VueAMap)
  .use(ViewUIPlus)
app.mount("#app");
