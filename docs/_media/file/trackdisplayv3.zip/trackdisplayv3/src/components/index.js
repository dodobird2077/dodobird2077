export const linePath = [
  {
    latitude: 39.997761,
    longitude: 116.478935,
    time: "2020-08-21 16:21:18",
  },
  {
    latitude: 39.997825,
    longitude: 116.478939,
    time: "2020-08-21 16:21:21"
  },
  {
    latitude: 39.998549,
    longitude: 116.478912,
    time: "2020-08-21 16:21:24"
  },
  {
    latitude: 39.998555,
    longitude: 116.478998,
    time: "2020-08-21 16:21:27"
  },
  {
    latitude: 39.99856,
    longitude: 116.479282,
    time: "2020-08-21 16:21:30"
  },
  {
    latitude: 39.998528,
    longitude: 116.479658,
    time: "2020-08-21 16:21:33"
  },
  {
    latitude: 39.998453,
    longitude: 116.480151,
    time: "2020-08-21 16:21:36"
  },
  {
    latitude: 39.998302,
    longitude: 116.480784,
    time: "2020-08-21 16:21:39"
  },
  {
    latitude: 39.998184,
    longitude: 116.481149,
    time: "2020-08-21 16:21:42"
  },
  {
    latitude: 39.997997,
    longitude: 116.481573,
    time: "2020-08-21 16:21:45"
  },
  {
    latitude: 39.997846,
    longitude: 116.481863,
    time: "2020-08-21 16:21:48"
  },
  {
    latitude: 39.997718,
    longitude: 116.482072,
    time: "2020-08-21 16:21:51"
  },
  {
    latitude: 39.997718,
    longitude: 116.482362,
    time: "2020-08-21 16:21:54"
  },
  {
    latitude: 39.998935,
    longitude: 116.483633,
    time: "2020-08-21 16:21:57"
  },
  {
    latitude: 39.998968,
    longitude: 116.48367,
    time: "2020-08-21 16:22:00"
  },
  {
    latitude: 39.999861,
    longitude: 116.484648,
    time: "2020-08-21 16:22:03"
  }
]
export const marks = [
  {
    latitude: 39.997761,
    longitude: 116.478935
  },
  {
    latitude: 39.99856,
    longitude: 116.479282
  },
  {
    latitude: 39.999861,
    longitude: 116.484648
  }
]